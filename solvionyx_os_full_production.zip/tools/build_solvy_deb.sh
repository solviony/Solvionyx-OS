#!/bin/bash
set -euo pipefail
echo 'Build Solvy AI DEB'
