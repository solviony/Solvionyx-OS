#!/bin/bash
set -euo pipefail
echo 'OEM Production Builder'
