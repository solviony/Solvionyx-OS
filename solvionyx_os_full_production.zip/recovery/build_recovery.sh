#!/bin/bash
set -euo pipefail
echo 'Recovery Production Builder'
