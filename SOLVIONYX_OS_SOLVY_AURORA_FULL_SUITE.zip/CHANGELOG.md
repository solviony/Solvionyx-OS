# Solvionyx OS — Aurora Changelog

## Aurora-v4.4.2 — 2025-10-17
- Automated Aurora build & release completed successfully.
- Added external/public download link to GitHub Release.

## Aurora-v4.4.2 — 2025-10-17
- Automated Aurora build & release completed successfully.
- Added external/public download link to GitHub Release.

## Aurora-v4.4.2 — 2025-10-18
- Automated Aurora build & release completed successfully.
- Added external/public download link to GitHub Release.
