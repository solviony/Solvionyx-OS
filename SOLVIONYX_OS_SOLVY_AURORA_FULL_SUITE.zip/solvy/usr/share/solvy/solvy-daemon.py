#!/usr/bin/env python3
import time, os, sys, json

LOG = "/tmp/solvy-daemon.log"

def log(msg):
    try:
        with open(LOG, "a") as f:
            f.write(msg + "\n")
    except Exception:
        pass

def main():
    log("Solvy daemon started.")
    log("NOTE: You must configure your OpenAI API key manually in this script before using voice features.")
    while True:
        time.sleep(60)

if __name__ == "__main__":
    main()
