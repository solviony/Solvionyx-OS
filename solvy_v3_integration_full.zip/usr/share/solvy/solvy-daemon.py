#!/usr/bin/env python3
import asyncio,os,json,importlib,glob
from aiohttp import web, WSMsgType

PLUGINS_DIR="/usr/share/solvy/plugins"

plugins={}
for path in glob.glob(PLUGINS_DIR+"/*.py"):
    name=os.path.basename(path)[:-3]
    mod=importlib.machinery.SourceFileLoader(name,path).load_module()
    if hasattr(mod,"run"):
        plugins[name]=mod.run

async def ws_handler(request):
    ws=web.WebSocketResponse()
    await ws.prepare(request)
    async for msg in ws:
        if msg.type==WSMsgType.TEXT:
            data=json.loads(msg.data)
            prompt=data.get("prompt","")
            # simple routing: detect tool keyword
            if prompt.startswith("tool:"):
                tool=prompt.split(":",1)[1]
                if tool in plugins:
                    out=plugins[tool]()
                    await ws.send_str(out)
                else:
                    await ws.send_str("unknown tool")
            else:
                await ws.send_str("solvy v3 placeholder response")
    return ws

app=web.Application()
app.router.add_get("/v1/ws",ws_handler)

if __name__=="__main__":
    web.run_app(app,host="0.0.0.0",port=3278)
